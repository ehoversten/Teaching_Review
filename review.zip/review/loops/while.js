
// Basic while loop
while (condition) {
    // execute code as long as condition is true
}

// Avoid the INFINATE LOOP (of DOOOOOOOOM)
while(true) {
    // code inside this loop will continue until you kill the server or process
}

// Basic Do/While loop
do {
    // execute code
} while (condition);

